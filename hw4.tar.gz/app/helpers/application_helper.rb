module ApplicationHelper
  #def page_title
  #  true
  #end
end
