require "spec_helper"

describe ApplicationHelper do
  #describe "#page_title" do
  #  it "returns true" do
  #    helper.page_title.should be_true
  #  end
  #end
end
